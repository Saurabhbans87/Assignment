package com.assignment;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;
import java.util.zip.CRC32;
import java.util.zip.Checksum;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Service
@RestController
@RequestMapping("/rest")
public class ApplicationService {
	
	
	@RequestMapping("/all")
	public String getAll() throws NoSuchAlgorithmException {
		String md5=md5Method();
		long crc32= crc32Method();
		long crc64= crc64Method();
		return "MD5 : " +md5 +"  "
				+"CRC32 : " + "  "
				+"CRC64 : "+ crc64 ;
	}

	@RequestMapping("/md5")
	public String md5Method() throws NoSuchAlgorithmException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter string");
		String str=sc.nextLine();
        MessageDigest messageDigest=MessageDigest.getInstance("MD5");
        messageDigest.update(str.getBytes(),0,str.length());
		return new BigInteger(1,messageDigest.digest()).toString(16);	
	}
	@RequestMapping("/crc32")
	private static long crc32Method() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter string");
		String str=sc.nextLine();
		byte bytes[] = str.getBytes();
		Checksum checksum = new CRC32();
		checksum.update(bytes, 0, bytes.length);
		long checksumValue = checksum.getValue();
		return checksumValue;
	}
	@RequestMapping("/crc64")
	private static long crc64Method() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter string");
		String str=sc.nextLine();
		StringBuffer stringBuffer=new StringBuffer(str);
		long upperBound = ((long)stringBuffer.hashCode()) << 32;
		long lowerBound = ((long)stringBuffer.reverse().hashCode())-((long) Integer.MIN_VALUE );
		long hash64 = upperBound + lowerBound;
		return hash64;
	}
}
