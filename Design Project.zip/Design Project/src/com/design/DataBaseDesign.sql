
/* Drop Tables */

DROP TABLE Answer CASCADE CONSTRAINTS;
DROP TABLE Question CASCADE CONSTRAINTS;
DROP TABLE User_Follower CASCADE CONSTRAINTS;
DROP TABLE User_Following CASCADE CONSTRAINTS;
DROP TABLE USER CASCADE CONSTRAINTS;
DROP TABLE Intrest_Type CASCADE CONSTRAINTS;
DROP TABLE Login_Details CASCADE CONSTRAINTS;




/* Create Tables */

CREATE TABLE Answer
(
	Answer_Id  NOT NULL,
	Answer_Title varchar2(20),
	Answer_Description varchar2(50),
	User_Id varchar2(0),
	Answer_Upvote number(50),
	Answer_DownVote number(50),
	Question_Id number(20) NOT NULL,
	Answer_Id number(20) NOT NULL,
	PRIMARY KEY (Answer_Id)
);


CREATE TABLE Intrest_Type
(
	Intrest_Id number(20) NOT NULL,
	Intrest_Area varchar2(50),
	Intrest_Location varchar2(50),
	PRIMARY KEY (Intrest_Id)
);


CREATE TABLE Login_Details
(
	User_Id varchar2(20) NOT NULL,
	User_Name varchar2(20),
	Email_Id varchar2(50),
	Password number,
	Is_Active number,
	PRIMARY KEY (User_Id)
);


CREATE TABLE Question
(
	Question_Id number(10) NOT NULL,
	Question_Key number(10),
	Question_Description varchar2(50),
	User_Id varchar2(20),
	Question_Upvote number(50),
	Question_DownVote number(50),
	Question_Id number(20) NOT NULL,
	Answer_Id number(20) NOT NULL,
	PRIMARY KEY (Question_Id)
);


CREATE TABLE USER
(
	User_Id varchar2(20) NOT NULL,
	User_Name varchar2(50),
	User_Votes number(20),
	Last_Login date,
	User_Follower_Id number(50),
	User_Following_Id number(50),
	User_Location varchar2(20),
	Intrest_Id number(20) NOT NULL,
	Question_Id number(20) NOT NULL,
	Answer_Id number(20) NOT NULL,
	PRIMARY KEY (Question_Id, Answer_Id)
);


CREATE TABLE User_Follower
(
	User_Id number(20) NOT NULL,
	User_Name varchar2(50),
	Question_Id number(20) NOT NULL,
	Answer_Id number(20) NOT NULL,
	PRIMARY KEY (User_Id)
);


CREATE TABLE User_Following
(
	User_Id number(20) NOT NULL,
	User_Name varchar2(20),
	Question_Id number(20) NOT NULL,
	Answer_Id number(20) NOT NULL,
	PRIMARY KEY (User_Id)
);



/* Create Foreign Keys */

ALTER TABLE USER
	ADD FOREIGN KEY (Intrest_Id)
	REFERENCES Intrest_Type (Intrest_Id)
;


ALTER TABLE USER
	ADD FOREIGN KEY (User_Id)
	REFERENCES Login_Details (User_Id)
;


ALTER TABLE Answer
	ADD FOREIGN KEY (Question_Id, Answer_Id)
	REFERENCES USER (Question_Id, Answer_Id)
;


ALTER TABLE Question
	ADD FOREIGN KEY (Question_Id, Answer_Id)
	REFERENCES USER (Question_Id, Answer_Id)
;


ALTER TABLE User_Follower
	ADD FOREIGN KEY (Question_Id, Answer_Id)
	REFERENCES USER (Question_Id, Answer_Id)
;


ALTER TABLE User_Following
	ADD FOREIGN KEY (Question_Id, Answer_Id)
	REFERENCES USER (Question_Id, Answer_Id)
;


/* Top 10 Question by score */
SELECT *
FROM Question
WHERE ROWNUM <= 10;

/* No of questions with less than 100 votes, no votes and less than 500 votes */
SELECT COUNT(Question_Id)
FROM Question
WHERE Question_Upvote < 100 OR Question_Upvote =0 OR Question_Upvote < 500;

/* score rank between 10-20 */
SELECT *
FROM Question
WHERE Question_Upvote BETWEEN 10 AND 20;



